package com.liyuxiang.film.config.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;

import java.io.Serializable;

public class AdminToken extends UsernamePasswordToken implements Serializable {


}
